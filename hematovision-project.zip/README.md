# HematoVision: Advanced Blood Cell Classification Using Transfer Learning

This project uses transfer learning (MobileNetV2) to classify blood cells.

## Project Structure
- `HematoVision.ipynb`: Model training & evaluation
- `app.py`: Streamlit web app to test image predictions
- `dataset/`: Training and testing images
- `model/`: Saved model files

## How to Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## GitHub Upload
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```
